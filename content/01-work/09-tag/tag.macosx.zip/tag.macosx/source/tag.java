import processing.core.*; 
import processing.data.*; 
import processing.opengl.*; 

import ddf.minim.spi.*; 
import ddf.minim.signals.*; 
import ddf.minim.*; 
import ddf.minim.analysis.*; 
import ddf.minim.effects.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class tag extends PApplet {

/*
TAG is an open source game project by Brannon Dorsey.
 Version 1.2.9 BETA includes:
 -a scoring system
 -a boost power up
 -a constrain power up
 -a disguise power up
 -NEW a sensor enlarge power up
 -powerups activate automatically (not with spacebar)
 -improved power up icons 
 -improved cloud positions when looped
 -power ups now have there own class
 -corrected Playground file name 
 -improved boundaries to fix freeze bug
 -soundtrack added!
 -NEW updated and improved instructions screen
 -NEW darker power up icons
 */

//minim library include 




//import ddf.minim.ugens.*;


//global variables
int wide; //width of canvas
int tall; //height of canvas
int s; //size of players
float sensorSize; //height of players sensors
float speed; //players speed
PImage vignette; //vignette image
PImage instructions; //instruction icon
PImage player1Image; //player 1 image
PImage player2Image; //player 2 image
PImage sensor1; //player 1 sensor image
PImage sensor2; //player 2 sensor image


//scores
int winningScore; //max score needed to win
int player1Score = 0; //player 1 score
int player2Score = 0; //player 2 score

//power ups
float boostSpeed; //players boost speed

//colors
int backgroundColor; 

//player start position
float player1X = wide/3-s; 
float player2X = wide*2/3;
float playerY  = tall/2-(s/2);

//players class
Player player1; //player 1
Player player2; //player 2

//power up class
PowerUp powerUp;

//playground class
Playground playground;

//info and menu class
InfoDisplay screen;

//minim
Minim minim;
AudioPlayer audioPlayer;
boolean playingMusic = false;

//KEYS
//contains true or false state of keys
boolean[] keys = new boolean[255]; 
//when key pressed keys[pressed key] = TRUE
public void keyPressed() {
  if (keyCode>255) return;
  keys[keyCode] = true;
}
//when key pressed keys[pressed key] = FALSE
public void keyReleased() {
  if (keyCode>255) return;
  keys[keyCode] = false;
}

//setup
public void setup() {
  
  //screen size adjusmtent for large screens
  if (displayWidth >= 1440){
      wide = 1440;
      tall = 900;
    }
  
  //sets applet to fullscreen if display is 1440x900 or smaller
    else{
      wide = displayWidth;
      tall = displayHeight; 
    }
  //----------------------------------------------// 
  //----------------------------------------------// 
  //global variables
  s = tall/10; //player size
  speed = wide/175; //player movement speed
  sensorSize = s/6; //player sensor height
  boostSpeed = 1.5f; //players boost speed
  winningScore =  5; //score needed to win
  //----------------------------------------------// 
  //----------------------------------------------// 
  
  //colors
  backgroundColor = 0xffffffff; //background color

  //player start position
  player1X = wide/3-s; 
  player2X = wide*2/3;
  playerY = tall/2-(s/2);

  //players objects
  player1 = new Player(player1X, playerY, s, speed, sensorSize, "WASD", boostSpeed); //player 1
  player2 = new Player(player2X, playerY, s, speed, sensorSize, "Arrows", boostSpeed); //player 2

  //playground object
  playground = new Playground(wide, tall);

  //power up object
  powerUp = new PowerUp(s, sensorSize, speed);

  //info and menus object
  screen = new InfoDisplay(winningScore); 
  
  //minim
  minim = new Minim(this);
  audioPlayer = minim.loadFile("canoecanoa.mp3");

  //canvas
  background(backgroundColor);
  frameRate(100);
  size(wide, tall);
  fill(0);
  smooth();

  /*-------MEDIA-------*/

  //font
  PFont font;
  font = loadFont("VisitorTT2BRK-170.vlw");
  textFont(font);
  textAlign(CENTER, CENTER);

  //images
  vignette = loadImage("vignette.png");
  instructions = loadImage("instructions.png");
  player1Image = loadImage("player1lighter.png");
  player2Image = loadImage("player2lighter.png");
  sensor1 = loadImage("sensor1.png");
  sensor2 = loadImage("sensor2.png");
}

//draw
public void draw() {
  playMusic(); //play music
  background(backgroundColor); //redo background
  playground.clouds(); //draw cloud blocks
  powerUp.display(); //draw power up icons
  screen.instructionsIcon(instructions); //draw instruction icon
  sensorEnlargeAllowed(); //test for if players are close enough to allow sensor enlarge power up
  if (screen.stillPlaying == true) updatePlayers(); //update players x and y positions
  player1.display(player1Image, sensor1); //player 1 
  player2.display(player2Image, sensor2); //player 2
  screen.scoreDisplay(player1Score, player1.controls); //display player 1 score
  screen.scoreDisplay(player2Score, player2.controls); //display player 2 score
  player1.score(player2.x, player2.y); //displays win screen if win occurs
  player2.score(player1.x, player1.y); //displays win screen if win occurs
  screen.winScreen(); //displays win screen
  screen.tie(player1.x, player1.y, player2.x, player2.y); //tie screen if players touch
  playground.vignette(vignette); //draw vignette
}

//plays music
public void playMusic(){
  
  //play music on first draw
  if (playingMusic == false){
    audioPlayer.play();
    audioPlayer.loop();
  } 
  playingMusic = true;
}

//evaluates if sensor enlarge power up is allowed
public void sensorEnlargeAllowed(){
  println(powerUp.sensorEnlargeSet);
  
  //if players are far enough away from eachother or large sensors have already been drawn
  if (dist(player1.x, player1.y, player2.x, player2.x) > s*2 ){
    player1.allowSensorEnlarge = true;
    player2.allowSensorEnlarge = true;
  }
  
  //if sensor was already enlarged
  else if(powerUp.sensorEnlargeSet == true){
    player1.allowSensorEnlarge = true;
    player2.allowSensorEnlarge = true;
  } 
  
  else{
    player1.allowSensorEnlarge = false; 
    player2.allowSensorEnlarge = false; 
  }
}

//update players x and y positions when keys are pressed
public void updatePlayers() {  
  if (keys[LEFT])  player2.move(-speed, 0); 
  if (keys[RIGHT]) player2.move(speed, 0); 
  if (keys[UP])    player2.move(0, -speed);
  if (keys[DOWN])  player2.move(0, speed);

  if (keys[65])  player1.move(-speed, 0); //a
  if (keys[68])  player1.move(speed, 0); //d
  if (keys[87])  player1.move(0, -speed); //w
  if (keys[83])  player1.move(0, speed);  //s 
}

//stop minim 
public void stop(){
  audioPlayer.close();
  minim.stop();
  super.stop();
}
class InfoDisplay{
  
  //class parameters
  int tieScreenLength   = 1000; //milliseconds that tie screen shows
  int scoreScreenLength   = 1500; //milliseconds that win screen shows
  int winScreenLength   = 5000; //milliseconds that win screen shows
  boolean stillPlaying  = true; //becomes false when play ends
  int blocksTouched     = 0; //gets millis() for when blocks touched

  int winningScore;
  float instructionsSize; //size of instructions icon
  float instructionsX; //x position of instructions icon
  float instructionsY; //y position of instructions icon
  
 //construct
 InfoDisplay(int tempWinningScore){
   winningScore = tempWinningScore;
  }
  
 //draws intstuctions icon
 public void instructionsIcon(PImage tempInstructions){
   PImage instructions = tempInstructions;
   
   instructionsSize = width/30; //size of instructions icon
   instructionsX = width/80;//wide-instructionsSize-wide/60;
   instructionsY = width/80;//tall-instructionsSize-tall/60;

   //if mouse over instructions icon execute instructionsScreen
   if(mouseX >= instructionsY &&
      mouseX <= instructionsY+instructionsSize &&
      mouseY >= instructionsX &&
      mouseY <= instructionsX+instructionsSize
      ) instructionsScreen(); //display instructions on mouse over
      
   image(instructions, instructionsX, instructionsY , instructionsSize, instructionsSize); //draws instructions icon
 }
  
 //displays instructions 
 public void instructionsScreen(){
   int lineHeight = width/20;
   
   //draws rectangle that tints screen black
   fill(0, 150); 
   rect(0,0, width, height);
   
   //draws instructions on screen
   fill(255);
   textSize(width/30);
   textAlign(LEFT);
   pushMatrix();
   //text("Tag is a two player game. Move your bot using the WASD or arrow keys. Hit your opponent's sensor (located on top of player) before they hit yours. Non-sensor contact always results in a tie. First player to five points wins. Watch out for power-ups!", width/5, height/4, width*3/5, height/2);
   text("> Tag is a two player game.", width/8, height/4, width*4/5, height/2); 
   translate(0, lineHeight);
   text("> Move your player using the WASD or arrow keys.", width/8, height/4, width*4/5, height/2); 
   translate(0, lineHeight);
   text("> Hit your opponent's sensor (located on top of player) before they hit yours.", width/8, height/4, width*3.8f/5, height/2);
   translate(0, lineHeight*1.5f); 
   text("> Non-sensor contact always results in a tie.", width/8, height/4, width*4/5, height/2); 
   translate(0, lineHeight); 
   text("> First player to five points wins.", width/8, height/4, width*4/5, height/2); 
   translate(0, lineHeight); 
   text("> Watch out for floating icons, their attributes effect both players!", width/8, height/4, width*4/5, height/2); 
   popMatrix();
 }
 
 //displays tie screen
 public void tie(float tempX, float tempY ,float tempOtherX, float tempOtherY){
      float otherX = tempOtherX; //other players x
      float otherY = tempOtherY; //other players y
      float x = tempX; // players x
      float y = tempY; // players y
      
      //displays tieScreen if players touch eachother
      if(x < otherX+s &&
         x+s > otherX &&
         y < otherY+s &&
         y+s > otherY) tieScreen(); //display tie screen
    
 }
  
 public void scoreDisplay(int score, String controls){
   int scoreX = width/2; //score x position
   if(controls.equals("WASD")) scoreX = width/10; //assign scoreX to left side of screen if controls are WASD
   else if(controls.equals("Arrows")) scoreX = width*9/10; //assign scoreX to right side of screen if controls are Arrows
   fill(0, 50); //set opacity for scores
   textSize(width/14.44f); //set font size
   textAlign(CENTER, CENTER); //sets text alignment
   text(score, scoreX, height/22); //draws score icon
 } 
  
 //draws tie screen
 public void tieScreen(){
     background(0, 100); 
     fill(255); 
     textSize(width/8.5f);
     textAlign(CENTER, CENTER);
     text("DRAW", width/2, height/2); //tie text
     stillPlaying = false; //stops updatePlayers
     if(blocksTouched == 0) blocksTouched = millis(); //sets millis() that blocks touched  
     
     //displays tie screen as long for the length of tieScreenLength
     if(millis() - blocksTouched >= tieScreenLength){ 
       setup(); //reset all but score variables
     }
    }
  
  //displays score screen
  public void scoreScreen(String tempControls){
      String controls = tempControls;
      background(0, 100); //color for score background
      fill(255); //color for score text
      textSize(width/9.6f);
      textAlign(CENTER, CENTER);
      text(controls+" Scores", width/2, height/2); //score text
      stillPlaying = false; //stops updatePlayers
      if(blocksTouched == 0) blocksTouched = millis(); //sets millis() that blocks touched  
       
      //displays tie screen as long for the length of tieScreenLength
      if(millis() - blocksTouched >= scoreScreenLength){
        
        //increase scores
        if(controls.equals("WASD")) player1Score++; //increase player 1 score by 1
        if(controls.equals("Arrows")) player2Score++; //increase player 2 score by 1
          
        setup(); //reset sketch/game
        loop(); // start draw
      }
  }
  
   public void winScreen(){
      String controls = "null"; //initializes controls
      if(player1Score == winningScore || player2Score == winningScore){
      if(player1Score == winningScore) controls = "WASD";
      if(player2Score == winningScore) controls = "Arrows";
      background(0, 100); //color for TIE background
      fill(255); //color for score text
      textSize(width/9.6f);
      textAlign(CENTER, CENTER);
      text(controls+" Wins!", width/2, height/2); //win text
      stillPlaying = false; //stops updatePlayers
      if(blocksTouched == 0) blocksTouched = millis(); //sets millis() that blocks touched  
       
      //displays tie screen as long for the length of tieScreenLength
      if(millis() - blocksTouched >= winScreenLength){
        
        //reset scores
        player1Score = 0;
        player2Score = 0;
        
        setup(); //reset sketch/game
        loop(); // start draw
     }
    }
   }
  }
 


class Player{
   
   //class parameters
   float x; // x position
   float y; // y position
   float sensorX; //sensor x position
   float sensorY; //sensor y position
   int s; //size
   float sensorSize; //sensor height
   float defaultSensorSize; //holds sensor size value to reset if changed
   float speed; //speed
   String controls; //controls
   int colors; //player color
   float otherX; //oposing players x value
   float otherY; //oposing players y value
   PImage playerImage; //player image
   float boostSpeed; //players boost speed
   
   boolean powerUpActive = false;
   boolean allowSensorEnlarge = false; 
  
     //construct
     Player(float tempX, float tempY, int tempS , float tempSpeed, float tempSensorSize, String tempControls, float tempBoostSpeed){
       x = tempX; 
       y = tempY; 
       s = tempS; 
       speed = tempSpeed; 
       controls = tempControls;
       sensorSize = tempSensorSize;
       defaultSensorSize = sensorSize; 
       boostSpeed = tempBoostSpeed;
     }
    
     //updates players x and y values
     public void move(float tempX, float tempY){
       //if power up is displaying, active, and boost
       if (powerUp.powerUpDisplaying == true &&
           powerUpActive == true &&
           powerUp.currentPowerUp == "boost"){
         tempX = tempX*boostSpeed;
         tempY = tempY*boostSpeed;
       }
       x += tempX;
       y += tempY;
     }
     
     //draws new players positions
     public void display(PImage playerImage, PImage sensor){
       
       //tests for if sensor enlarge power up is active and players arent too close
       if(powerUp.currentPowerUp == "sensorEnlarge" &&
          powerUp.powerUpDisplaying == true &&
          allowSensorEnlarge == true
          ){
            sensorSize = powerUp.sensorEnlargeSize; //enlarge sensor
            powerUp.sensorEnlargeSet = true; //allows sensor to stay on
          }
          
       else sensorSize = defaultSensorSize; //resets sensor size if sensor enlarge power up is not active
       
       //wraparound
       boundaries();
       
       // draw player
       image(playerImage, x, y-2, s, s); //draw player using image
       fill(0,100);
       imageMode(CORNERS);//changes rectMode to corners to draw sensor
       image(sensor, x, y, x+s, y-sensorSize); //draw players sensor
       imageMode(CORNER); //resets rectMode      
     }
     
     //displays winner screen if player hits others sensor
     public void score(float tempOtherX, float tempOtherY){
       
      otherX = tempOtherX;
      otherY = tempOtherY;
      
      //displays win screens if a player touches other players sensor
      if (x < otherX+s &&
          x+s > otherX &&
          y < otherY-sensorSize &&
          y+s > otherY-sensorSize){
            
          screen.scoreScreen(controls); //launches win screen from InfoDisplay class if win has not occured
      }
     }
      
      //pacman style wraparound
      public void boundaries(){
        //if power up is displaying, active, and current power up is constrain
       if (powerUp.powerUpDisplaying == true &&
           powerUpActive == true &&
           powerUp.currentPowerUp == "constrain"){
             x = constrain(x, 1, width-s-1); //constrain player to left and right borders
             y = constrain(y, 1+sensorSize, height-s-1); //constrain player to top and bottom borders
           }
       
       if(x+s >= width) x = 1;
       if(y+s >= height) y = 1+sensorSize;
       if(x <= 0) x = width-s-1;
       if(y-sensorSize <= 0) y = height-s;
      }
    }
class Playground{
  
  //class parameters
  int cloudMin        = 75; //minimum size for cloud
  int cloudMax        = 300; //maximum size for cloud
  int cloudNumber     = 150; //number of clouds
  float cloudSpeed    = 1; // cloud speed
  int cloudDistance   = -2000; // distance clouds can start from fram
  float[] cloudX      = new float[cloudNumber+1]; //creates array for cloud x positions
  float[] cloudY      = new float[cloudNumber+1]; //creates array for cloud y positions
  float[] cloudWidth  = new float[cloudNumber+1]; //creates array for cloud width
  float[] cloudHeight = new float[cloudNumber+1]; //creates array for cloud height
  
  //construct
  Playground(int tempWide, int tempTall){
      int wide = tempWide; //sets canvas x value as sent by object instantiation parameter
      int tall = tempTall; //sets canvas y value as sent by object instantiation parameter
      
      //populates cloudX, cloudY arrays with random numbers
      for(int varCreate = 0; varCreate <= cloudNumber; varCreate++){
        cloudX[varCreate]      = PApplet.parseInt(random(cloudDistance, wide)); //random cloud x position
        cloudY[varCreate]      = PApplet.parseInt(random(0, tall)); //random cloud y position
        cloudWidth[varCreate]  = PApplet.parseInt(random(cloudMin, cloudMax/2)); //random cloud width
        cloudHeight[varCreate] = PApplet.parseInt(random(cloudMin, cloudMax)); //random cloud height
      }
  }
  
 //make block clouds 
 public void clouds(){
  fill(0, 10); //fill color and opacity for clouds
  noStroke(); 
  
  //draw clouds
  for(int i = 0; i <= cloudNumber; i++){
    rect(cloudX[i], cloudY[i], cloudWidth[i], cloudHeight[i]);
    
    //update cloud variables
    cloudX[i] += cloudSpeed;
    
    //loops clouds
    if(cloudX[i] > width+cloudMax){
      cloudX[i] = cloudDistance+cloudWidth[i]*2; //positions cloud x position at cloudDistance if cloud has passed the screen
    }
  }  
 }
 
 public void vignette(PImage vignette){
   image(vignette, 0, 0, width, height); //draw vignette image
 }
}


class PowerUp{
 
 //class properties
  int powerUpChance = 600; //chance that power up will occur
  float powerUpIconSpeed = displayWidth*.0018f; //power up icon speed
  int directionChangeChance = 100; //chance that disguise bot will change directions
  
  String[] direction = {"up", "down", "left", "right", "upLeft", "upRight", "downLeft", "downRight"}; //directions for bot
  int directionIndex; //index for direction array 
  String botDirection; //holds selected direction string 
  String[] powerUp = {"boost", "constrain", "disguise", "sensorEnlarge"}; //string array to contain power up names
  String currentPowerUp; //current power up
  int powerUpIndex; //index to select power up randomly in powerUp();
  float powerUpWidth = displayWidth/5.76f; //width of power up icon
  float powerUpHeight = displayHeight/6; //height of power up icon
  float boostWidth = powerUpWidth*1.45f; //boost width to account for ellongated icon
  float boostHeight = powerUpHeight*1.45f; //boost height to account for ellongated icon
  float disguiseWidth = powerUpWidth/1.32f; //disguise height to accound for narrower smaller icon
  boolean active = false; //boolean for if disguise power up is active
  boolean previouslyActive = false; //boolean for if disguise power up was active
  boolean powerUpDisplaying = false; //boolean for if power up icon is displaying
  boolean sensorEnlargeSet = false; //boolean for if enlarged sensor has already been drawn 
  float sensorEnlargeSize; //size of sensor for sensor enlarge power up
 
  //timer properies
  boolean currentlyRecordingTime = false; //boolean to record millis timer state
  long timeIconStarted; //holds millis() for when disguise icon starts
  int delay = 700; //delay between icon start and power up activation (to allow players to see powerup before powerup starts)
  
  //bot properties
  PImage boostImage; //boost icon image
  PImage constrainImage; //constrain icon image
  PImage disguiseImage; //disguise icon image
  PImage botImage; //disguise bot image
  PImage botSensorImage; //disguise bot sensor image
  PImage sensorEnlargeImage; //sensor enlarge icon image
  float powerUpPositionX; //power up icon x position
  float powerUpPositionY; //power up icon y position
  float botX; //disguise bot x position
  float botY; //disguies bot y position
  float botSize; //disguise bot size
  float botSensorSize; //disguise bot sensor size
  float botSpeed; //disguies bot speed
  
 //construct
 PowerUp(float tempBotSize, float tempBotSensorSize, float tempBotSpeed){
    botSize = tempBotSize; 
    botSensorSize = tempBotSensorSize;
    botSpeed = tempBotSpeed;
    
    directionIndex = PApplet.parseInt(random(direction.length)); //value selects random index of direction array
    powerUpIndex = PApplet.parseInt(random(powerUp.length)); //value selects random index of powerUp string
    powerUpPositionY = random(displayHeight-powerUpHeight); //randomly chooses power up Y position
    powerUpPositionX -= powerUpWidth; //starts icon off screen left  
    botX = PApplet.parseInt(random(width-botSize)); //random bot x position
    botY = PApplet.parseInt(random(height-botSize)); //random bot y position
    botDirection = "up"; //default bot direction
    
    sensorEnlargeSize = botSensorSize*3; //size of sensor enlare power up sensor
      
    //Media
    boostImage = loadImage("boost.png"); //load boost image
    constrainImage = loadImage("constrain.png"); //load constrain image
    disguiseImage = loadImage("disguise.png"); //load disguise image
    botImage = loadImage("bot.png"); //load bot image
    botSensorImage = loadImage("botsensor.png"); //load bot image
    sensorEnlargeImage = loadImage("sensorenlarge.png"); //loads sensor enlarge image
 }
 
  //draws power ups 
 public void display(){
   int powerUpTry = PApplet.parseInt(random(powerUpChance)); // random number to try and draw power up
   currentPowerUp = powerUp[powerUpIndex]; // picks power up (name)
   PImage powerUpImage = boostImage; //default power up image
   
   //reset power up width 
   if(currentPowerUp != "boost"){
       powerUpWidth = displayWidth/5.76f; // reset width of power up icon
       powerUpHeight = displayHeight/6; // reset height of power up icon
   }
   
   /*---------BOOST---------*/
   //if power up is boost
   if(currentPowerUp == "boost"){
     powerUpImage = boostImage; //assigns power up image to chosen power up
     powerUpWidth = boostWidth; //change power up width to boost width
     powerUpHeight = boostHeight; //change power up width to boost height
   }
   
   /*---------CONSTRAIN---------*/
   //if power up is constrain
   else if(currentPowerUp == "constrain") powerUpImage = constrainImage; //assigns power up image to chosen power up
    
   /*---------DISGUISE---------*/
   //if power up is disguise and displaying
   else if(currentPowerUp == "disguise" &&
           powerUpDisplaying == true){
     powerUpImage = disguiseImage; //assigns power up image to chosen power up
     powerUpWidth = disguiseWidth; //change power up width to disguise image width
     boundaries(); //pacman wraparound for bot
     disguise(); //draw bot
     moveDisguiseBot(botSpeed); //move bot
     active = false; //reset active state
   }
   
    /*---------SENSOR ENLARGE---------*/
   //if power up is sensor enlarge 
   else if(currentPowerUp == "sensorEnlarge") powerUpImage = sensorEnlargeImage;
  
   else{
     active = false; //no power up is active
     currentlyRecordingTime = false; //reset disguise delay timer
     sensorEnlargeSet = false; //does not allow enlarged sensor to be redrawn
   }
   
   //if boost try is 0 and there is not currently a power up
   if(powerUpTry == 0 && powerUpDisplaying == false){
     powerUpDisplaying = true; //allow boost power up
     player1.powerUpActive = true; //activate power up
     player2.powerUpActive = true; //activate power up
   }
   
   //if power up is allowed
   if(powerUpDisplaying == true){
     image(powerUpImage, powerUpPositionX, powerUpPositionY, powerUpWidth, powerUpHeight); //draw power up image
     powerUpPositionX += powerUpIconSpeed; //move power up icon
    
     //if boost icon leaves screen
     if(powerUpPositionX >= width){
       powerUpDisplaying = false; //do not allow power up icon
       powerUpPositionX = -powerUpWidth; //reset power up x positions
       powerUpPositionY = random(displayHeight-powerUpHeight); //randomly chooses next power up Y position
       powerUpIndex = PApplet.parseInt(random(powerUp.length)); //resets power up picker
     }     
   }
  }

  //draws disguise bot
  public void disguise(){
   
    //delay to account for disguise icon visibility on screen
    if(currentlyRecordingTime == false){
      timeIconStarted = millis();
      currentlyRecordingTime = true;
    }
    
    if(millis()-timeIconStarted >= delay){
      if(previouslyActive == false){
        botX = PApplet.parseInt(random(width-botSize)); //resets random bot x position
        botY = PApplet.parseInt(random(height-botSize)); //resets random bot y position
      }
      image(botImage, botX, botY, botSize, botSize); //draw bot
      imageMode(CORNERS);//changes rectMode to corners to draw sensor
      image(botSensorImage, botX, botY, botX+botSize, botY-botSensorSize); //draw bot sensor
      imageMode(CORNER); //resets rectMode   
      previouslyActive = true; //change previously active state 
    }
  }
  
  //moves diguise bot
  public void moveDisguiseBot(float speed){
    int directionChangeTry = PApplet.parseInt(random(directionChangeChance)); // random number to try and change bot direction
 
    if(directionChangeTry == 0){
      botDirection = direction[directionIndex]; //
      directionIndex = PApplet.parseInt(random(direction.length)); //reset random index of direction array
    }
    
    //update botX and botY according to botDirection for movement
    if(botDirection == "up") botY += botSpeed;
    else if(botDirection == "down") botY -= botSpeed;
    else if(botDirection == "right") botX += botSpeed;
    else if(botDirection == "left") botX -= botSpeed;
    else if(botDirection == "upLeft"){
        botX -= botSpeed;
        botY -= botSpeed;
    }
    else if(botDirection == "upRight"){
        botX += botSpeed;
        botY -= botSpeed;
    }
    if(botDirection == "downLeft"){
        botX -= botSpeed;
        botY += botSpeed;
    }
    if(botDirection == "downRight"){
        botX += botSpeed;
        botY += botSpeed;
    }
  }
  
  //pacman style wraparound for bot
 public void boundaries(){
    if(botX+botSize >= width) botX = 1;
    if(botY+botSize >= height) botY = 1+botSensorSize;
    if(botX <= 0) botX = width-s-1;
    if(botY-botSensorSize <= 0) botY = height-botSize;
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "tag" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
